console.log("Inside Dialog JS file");
document.addEventListener("DOMContentLoaded", () => {
    console.log("Dialog HTML has been Loaded");

    tableau.extensions.initializeAsync().then(function () {
        console.log("tableau extension initialized");
        fetchFilters();
    }, function (err) {
        // Something went wrong in initialization.
        console.log('Error while Initializing: ' + err.toString());
    });
});

function fetchFilters() {
    console.log("Inside the fetchFilters function");

    let filtersPresentInDashboard = [];
    const dashboard = tableau.extensions.dashboardContent.dashboard;

    //  Get all filter list applied on dashboard
    let dashboardObject = dashboard.objects;
    console.log("dashboardObject -- >", dashboardObject);

    // var viz = new tableau.Viz("dialog.html", "https://pixelperfecttableau.useready.com/authoring/TrainingDashboard/IncentiveCompensationReport?#1", "");

    dashboardObject.forEach(function (item) {

        try {
            if (item.type === "quick-filter") {
                // ... rest of your code ...
                filtersPresentInDashboard.push(item.name);
                console.log("Item-Name --> ", item.name);
                console.log("Item --> ", item);
                console.log("Item-Type --> ", item.appliedValues);
               

                const valueStr = getFilterValues(item);

                console.log("Value: --> ", valueStr);

            // Get the filter object
            // Initialize the Tableau Viz object
            // var viz = new tableau.Viz(containerDiv, url, options);

            // console.log("Before getting filter object");
            // var filterPromise = viz.getWorkbook().getFilterAsync(item.name);
            // console.log("Before getting filter object");
            // console.log("---- FilterPromise ----", filterPromise);

            // // Fetch selected values
            // filterPromise.then(function (filter) {
            //     filter.getAppliedValuesAsync().then(function (selectedValues) {
            //         console.log("Item-Values --> ", selectedValues.map(value => value.formattedValue));
            //     }).catch(function (error) {
            //         console.error("Error fetching selected values:", error);
            //     });
            // }).catch(function (error) {
            //     console.error("Error fetching filter:", error);
            // });
            // }
        }} catch (error) {
            console.error("Error:", error);
        }


        if (item.type === "quick-filter") {
            // filtersPresentInDashboard.push(item.name);
            // console.log("Item-Name --> ", item.name);
            // console.log("Item-Value --> ", item.filterValue);

            // const valueStr = getFilterValues(item);

            // console.log("Value: --> ", valueStr);

            // // Get the filter object
            // console.log("Before getting filter object");
            // var filterPromise = viz.getWorkbook().getFilterAsync(item.name);
            // console.log("Before getting filter object");
            // console.log("---- FilterPromise ----", filterPromise);

            // // Fetch selected values
            // filterPromise.then(function (filter) {
            //     filter.getAppliedValuesAsync().then(function (selectedValues) {
            //         console.log("Item-Values --> ", selectedValues.map(value => value.formattedValue));
            //     }).catch(function (error) {
            //         console.error("Error fetching selected values:", error);
            //     });
            // }).catch(function (error) {
            //     console.error("Error fetching filter:", error);
            // });



        }
    });
    console.log("filterPresent --> ", filtersPresentInDashboard);

    function getFilterValues (filter) {
        console.log("--- Inside getFilterValues ---");
        let filterValues = '';
    
        switch (filter.type) {
            case 'categorical':
                filter.appliedValues.forEach(function (value) {
                    filterValues += value.formattedValue + ', ';
                });
                break;
            case 'quick-filter':
                filter.appliedValues.forEach(function (value) {
                    filterValues += value.formattedValue + ', ';
                });
                console.log("FilterValues --> ", filterValues);
                break;
            case 'range':
                // A range filter can have a min and/or a max.
                if (filter.minValue) {
                    filterValues += 'min: ' + filter.minValue.formattedValue + ', ';
                }

                if (filter.maxValue) {
                    filterValues += 'max: ' + filter.maxValue.formattedValue + ', ';
                }
                break;
            case 'relative-date':
                filterValues += 'Period: ' + filter.periodType + ', ';
                filterValues += 'RangeN: ' + filter.rangeN + ', ';
                filterValues += 'Range Type: ' + filter.rangeType + ', ';
                break;
            default:
        }
    
        // Cut off the trailing ", "
        return filterValues.slice(0, -2);
      }


    var select = document.getElementById("filterSelect");
    console.log("select: ", select);

    filtersPresentInDashboard.forEach((filterValue) => {
        var option = document.createElement("option");
        option.text = filterValue;
        option.value = filterValue;
        console.log(option.text);
        select.add(option);
    })

    console.log("select post loop :", select);

}