'use strict';
console.log("Inside CitiReq JS file");
var fieldMap = new Map();
var fieldName ="";
var fieldValues = "";
const unregisterHandlerFunctions = [];
var selectedOptions = "";
var enteredUrl = "";
// to ensure that JavaScript code doesn't run before the necessary HTML elements are available in the DOM
document.addEventListener("DOMContentLoaded", () => {
    console.log("HTML has been loaded");
    // var fieldMap = new Map();
    // var fieldName ="";
    // var fieldValues = "";
    try {
        tableau.extensions.initializeAsync({ 'configure': configure }).then(function () {
            console.log("Initialization completed.");
            console.log("dashboard ---> ", tableau.extensions.dashboardContent.dashboard);

            // fetchFilters();


            // For opening up a dialog box, after clicking on Configure...
            const dialogOptions = {
                "width": 400,
                "height": 300
            };

            tableau.extensions.ui.displayDialogAsync("dialog.html", "", dialogOptions)
                .then(function (closePayload) {
                    console.log("Dialog closed with payload:", closePayload);
                    // Handling the dialog's response here
                    if (closePayload !== null) {
                        console.log("Dialog Window is closed now");
                        // Handle the saved data here
                        // const selectedOptions = closePayload.input1;
                        // const enteredUrl = closePayload.input2;
                        selectedOptions = closePayload.input1;
                        enteredUrl = closePayload.input2;

                        // Create a button with the saved data
                        createButton(selectedOptions, enteredUrl);
                    }
                })
                .catch(function (error) {
                    console.log("Error opening dialog:", error);
                });

        })
            .catch(function (error) {
                console.error("Inside initialization's catch:", error);
            });
    } catch (error) {
        console.log("Initialization error:", error);
    }

});

function fetchFilters(){
    console.log("Inside Fetch Filters");

    return new Promise(function (resolve, reject) {
        // Your fetchFilters() logic, which may involve asynchronous operations
        // Resolve the Promise when fetchFilters() is completed

        unregisterHandlerFunctions.forEach(function (unregisterHandlerFunction) {
            unregisterHandlerFunction();
        });

        console.log("Inside Fetch Filters");
        const filterFetchPromises = [];
        const dashboardfilters = [];
        const dashboard = tableau.extensions.dashboardContent.dashboard;
        // filterFetchPromises.push(dashboard.getFiltersAsync());
        dashboard.worksheets.forEach(function (worksheet) { 
    
            filterFetchPromises.push(worksheet.getFiltersAsync());
      
            // Add filter event to each worksheet.  AddEventListener returns a function that will
            // remove the event listener when called.
            const unregisterHandlerFunction = worksheet.addEventListener(tableau.TableauEventType.FilterChanged, filterChangedHandler);
            unregisterHandlerFunctions.push(unregisterHandlerFunction);
          });
    
          Promise.all(filterFetchPromises).then(function (fetchResults) {
            fetchResults.forEach(function (filtersForWorksheet) {
              filtersForWorksheet.forEach(function (filter) {
                dashboardfilters.push(filter);
              });
            });
            console.log("Dashboard Filters: ",dashboardfilters);
            buildFiltersTable(dashboardfilters);
          });
    
        console.log("filterFetchPromise:", filterFetchPromises);

        resolve();
    });

}

// This is a handling function that is called anytime a filter is changed in Tableau.
function filterChangedHandler (filterEvent) {
    // Just reconstruct the filters table whenever a filter changes.
    // This could be optimized to add/remove only the different filters.
    console.log("Some Filter value is changed");
    fetchFilters();
    // createButton(selectedOptions, enteredUrl);

}

function buildFiltersTable (filters) {
    filters.forEach(function (filter) {
        fieldName =filter.fieldName;
        
        const valueStr = getFilterValues(filter);
        fieldValues = valueStr;
        // console.log("Filed Name --> ", filter.fieldName);
        // console.log("Filed value --> ", valueStr);
        // Store the data in the Map only if the key doesn't exist yet
        // if (!fieldMap.has(fieldName)) {
        //     fieldMap.set(fieldName, fieldValues);
        // }

        if (fieldMap.has(fieldName)) {
            // If it exists, override the values
            fieldMap.set(fieldName, fieldValues);
        } else {
            // If it doesn't exist, add a new entry
            fieldMap.set(fieldName, fieldValues);
        }
    });

  }

  function getFilterValues (filter) {
    console.log("Inside GetFilterValues method");
    let filterValues = '';
    // console.log("filter --> ",filter);

    switch (filter.filterType) {
      case 'categorical':
        // console.log("appliesValues -- >", filter.appliedValues);
        filter.appliedValues.forEach(function (value) {
          filterValues += value.formattedValue + ', ';
        });
        break;
      case 'range':
        // A range filter can have a min and/or a max.
        if (filter.minValue) {
          filterValues += 'min: ' + filter.minValue.formattedValue + ', ';
        }

        if (filter.maxValue) {
          filterValues += 'max: ' + filter.maxValue.formattedValue + ', ';
        }
        break;
      case 'relative-date':
        filterValues += 'Period: ' + filter.periodType + ', ';
        filterValues += 'RangeN: ' + filter.rangeN + ', ';
        filterValues += 'Range Type: ' + filter.rangeType + ', ';
        break;
      default:
    }

    // Cut off the trailing ", "
    return filterValues.slice(0, -2);
  }

function configure() {
    console.log("Inside Configure Function");
    // if (extensions.environment.context == "desktop") {
    // 	let settings = extensions.settings.getAll();
    // 	if (Object.keys(settings).length > 0) {
    // 		openPixelPerfectServer()
    // 	} else {
    // 		openPPRConfigurationDesktop()
    // 	}
    // } else {
    // 	openPixelPerfectServer();
    // }
    // openPixelPerfectServer();
}

function createButton(selectedOptions, enteredUrl) {
    console.log("Inside CreateButton");

    const body = document.getElementById("mainBody");
    const newButton = document.createElement('button');
    // newButton.textContent = `Button (${selectedOptions}, ${enteredUrl})`;
    newButton.textContent = "Click to POST data";
    body.appendChild(newButton);

    newButton.addEventListener('click', () => {
        // fetchFilters();
        // sendPostRequest(selectedOptions, enteredUrl);


        fetchFilters().then(() => {
            setTimeout(() => {
                sendPostRequest(selectedOptions, enteredUrl);
            }, 3000); // 3000 milliseconds = 3 seconds
        }).catch(error => {
            console.error("Error:", error);
        });
    });
    
}

function sendPostRequest(selectedOptions, enteredUrl) {
    // fetchFilters();

    console.log("Available Filters: ", fieldMap);
    var selectedFilterMap = new Map();

    // Iterate through selectedOptions and check if each key exists in fieldMap
    selectedOptions.forEach(function (option) {
        if (fieldMap.has(option)) {
            selectedFilterMap.set(option, fieldMap.get(option));
        }
    });

    console.log("Selected filters and its Value: ", selectedFilterMap);

    var dataObject = {};
    selectedFilterMap.forEach((value, key) => {
        dataObject[key] = value.split(", "); // Convert comma-separated string to an array
    });

    // fetchFiltersValue();

    console.log("url for Post Req --> ", enteredUrl);
    console.log("Selected Filters --> ", selectedOptions);
    const url = enteredUrl;// e.g. "https://your-backend-api-url"; 
    const data = {
        // filters: selectedOptions
        filters: selectedFilterMap
    };

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dataObject)
    })
        .then(response => response.json())
        .then(result => {
            // Handle the response from the API if needed
            console.log("API response:", result);
        })
        .catch(error => {
            // Handle error
            console.error("Error:", error);
        });
}

function fetchFiltersValue() {
    // Container div where the Tableau viz will be embedded
    // var containerDiv = document.getElementById("yourContainerDiv");

    // URL of the Tableau dashboard to embed
    var url = "https://pixelperfecttableau.useready.com/authoring/TrainingDashboard/IncentiveCompensationReport?#1";

    // Options for embedding the viz
    var options = {
        hideTabs: true,
        onFirstInteractive: function () {
            // Viz initialization is complete, now fetch filters
            fetchAllFiltersWithSelectedValues(viz);
        }
    };

    // Initialize the Tableau Viz object
    var viz = new tableau.Viz("extension.html", url, options);

    // Method to fetch all filters with selected values
    function fetchAllFiltersWithSelectedValues(viz) {
        viz.getWorkbook().getActiveSheet().getFiltersAsync().then(function (filters) {
            filters.forEach(function (filter) {
                var filterInfo = {
                    name: filter.getFieldName(),
                    type: filter.getFilterType(),
                    selectedValues: []
                };

                if (filter.getFilterType() === tableau.FilterType.CATEGORICAL) {
                    filter.getAppliedValuesAsync().then(function (selectedValues) {
                        filterInfo.selectedValues = selectedValues.map(value => value.formattedValue);
                        console.log("Filter Info:", filterInfo);
                    }).catch(function (error) {
                        console.error("Error fetching selected values:", error);
                    });
                } else {
                    console.log("Filter Info:", filterInfo);
                }
            });
        }).catch(function (error) {
            console.error("Error fetching filters:", error);
        });
    }

}






